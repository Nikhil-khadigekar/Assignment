 import Chat from "./Chat";

function App() {
  return (
    <div style={{textAlign:"center",marginTop:"40px"}}>
      <h2>AI Powered Support Assistant</h2>
      <Chat />
    </div>
  );
}

export default App;